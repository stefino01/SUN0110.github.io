<?php
return array(
    'app.shop'      => array(
        'strict'  => true,
        'version' => '6.0.0.37522',
    ),
    'php.curl'      => array(
        'strict' => false,
    ),
    'php.url_fopen' => array(
        'strict' => false,
    ),
);
