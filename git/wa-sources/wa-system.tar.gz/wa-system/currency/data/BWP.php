<?php

return array(
    'code' => 'BWP',
    'sign' => 'P',
	'iso4217' => '72',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Botswana pula',
    'name' => array(
        'pula',
    ),
    'frac_name' => array(
        'thebe',
    )
);