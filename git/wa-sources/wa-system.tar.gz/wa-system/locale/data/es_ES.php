<?php

return array(
    'name' => 'Español',
    'region' => 'España',
    'english_name' => 'Spanish',
    'english_region' => 'Spain'

);