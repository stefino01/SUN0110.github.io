<?php
return array(
    'app.installer' => array(
        'version' => '>=1.13',
        'strict'  => true,
    ),
);
