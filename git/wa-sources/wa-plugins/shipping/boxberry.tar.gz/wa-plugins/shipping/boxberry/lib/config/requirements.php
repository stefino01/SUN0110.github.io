<?php
return array(
    'php' => array(
        'version' => '>=5.6',
        'strict'  => true,
    ),
    'app.installer' => array(
        'version' => '>=1.14.5',
        'strict'  => true,
    )
);
