<?php
return 42;
